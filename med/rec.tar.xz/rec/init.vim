set number
set relativenumber
set expandtab
set wrap
set ruler
set cursorline 
set smartcase
set ignorecase
set mouse=nvi
set noswapfile

colorscheme retrobox

" Start NERDTree. If a file is specified, move the cursor to its window.
autocmd StdinReadPre * let s:std_in=1
autocmd VimEnter * NERDTree | if argc() > 0 || exists("s:std_in") | wincmd p | endif
