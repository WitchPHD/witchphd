#! /bin/bash

# this script copies config files I use to here to recover from later

echo ' '
read -p ' >> enter: cp config files from system to ./.configs' x
# cp ~/.config/kitty/kitty.conf $(dirname "$0")/.configs/silverblue/kitty.conf
# cp ~/.config/starship.toml $(dirname "$0")/.configs/silverblue/starship.toml 
# cp ~/.config/nvim/init.vim $(dirname "$0")/.configs/silverblue/init.vim
# cp /etc/pacman.conf $(dirname "$0")/.configs/silverblue/pacman.conf
cp ~/.bashrc $(dirname "$0")/.configs/silverblue/.bashrc
