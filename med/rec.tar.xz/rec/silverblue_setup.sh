#! /bin/bash

# this script installs all the programs for my desktop

echo ' '
echo ' >> this script is for setting up my silverblue daily driver'
read -p ' >> before hitting enter, you must enable flathub in software center repositories' x

echo ' '
read -p ' >> enter: uninstall bloat, disable some things' x
flatpak remove calculator calendar connections contacts maps papers weather clocks eog
gsettings set org.gnome.software allow-updates false
# disable wifi powersafe so things don't disconnect in background
sudo tee /etc/NetworkManager/conf.d/00-wifi-powersave.conf << EOF > /dev/null
[connection]
wifi.powersave=2
EOF

echo ' '
read -p ' >> enter: install flathub apps' x
flatpak remote-modify --no-filter --enable flathub
flatpak install flathub com.discordapp.Discord com.github.tchx84.Flatseal org.gimp.GIMP org.kde.gwenview org.libreoffice.LibreOffice com.obsproject.Studio com.valvesoftware.Steam org.telegram.desktop com.transmissionbt.Transmission org.videolan.VLC org.mozilla.firefox org.mozilla.thunderbird

echo ' '
read -p ' >> enter: since we use flathub firefox, hide the image firefox' x
sudo mkdir -p /usr/local/share/applications
sudo cp /usr/share/applications/org.mozilla.firefox.desktop /usr/local/share/applications/
sudo sed -i "2a\\NotShowIn=GNOME;KDE" /usr/local/share/applications/org.mozilla.firefox.desktop
sudo update-desktop-database /usr/local/share/applications/
# note: to renable use
# sudo rm -f /usr/local/share/applications/org.mozilla.firefox.desktop
# sudo update-desktop-database /usr/local/share/applications 
 
 
echo ' '
read -p ' >> enter: cp config files from ./.configs to system' x
sudo mkdir -p /etc/systemd/logind.conf.d/
# mkdir -p ~/.config/nvim
# cp $(dirname "$0")/.configs/silverblue/kitty.conf ~/.config/kitty/kitty.conf
# cp $(dirname "$0")/.configs/silverblue/starship.toml ~/.config/starship.toml 
# cp $(dirname "$0")/.configs/silverblue/init.vim ~/.config/nvim/init.vim
cp $(dirname "$0")/.configs/silverblue/.bashrc ~/.bashrc
cp $(dirname "$0")/.configs/silverblue/logind.conf /etc/systemd/logind.conf.d/logind.conf

echo ' '
read -p ' >> enter: run updates' x
flatpak update
rpm-ostree update

echo ' ' 
read -p ' >> manual: enable korean in settings' x
read -p ' >> manual: enable nightlight in settings' x
read -p ' >> manual: enable move reminders in settings' x
read -p ' >> manual: dark theme with purple accent' x
read -p ' >> manual: set wallpaper' x
read -p ' >> manual: set hotkeys:' x
echo '     - [sup + spc] ptyxis '
echo '     - [alt + spc] file '
echo '     - [sup + tab] change input '
