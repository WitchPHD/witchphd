#! /bin/bash

# this script installs all the programs for my desktop

echo ' '
echo ' >> this script is for setting up my silverblue daily driver'
read -p ' >> before hitting enter, you must enable flathub in software center repositories' x

echo ' '
read -p ' >> enter: uninstall bloat' x
flatpak remove calculator calendar connections contacts maps papers weather clocks eog

echo ' '
read -p ' >> enter: install my apps' x
flatpak install flathub com.discordapp.Discord com.github.tchx84.Flatseal org.gimp.GIMP org.kde.gwenview org.libreoffice.LibreOffice io.neovim.nvim com.obsproject.Studio com.valvesoftware.Steam org.telegram.desktop com.transmissionbt.Transmission org.videolan.VLC

echo ' '
read -p ' >> enter: cp config files from ./.configs to system' x
# mkdir -p ~/.config/nvim
# cp $(dirname "$0")/.configs/silverblue/kitty.conf ~/.config/kitty/kitty.conf
# cp $(dirname "$0")/.configs/silverblue/starship.toml ~/.config/starship.toml 
# cp $(dirname "$0")/.configs/silverblue/init.vim ~/.config/nvim/init.vim
cp $(dirname "$0")/.configs/silverblue/.bashrc ~/.bashrc

echo ' '
read -p ' >> enter: run updates' x
flatpak update
rpm-ostree update

echo ' ' 
read -p ' >> manual: enable korean in settings' x
read -p ' >> manual: enable nightlight in settings' x
read -p ' >> manual: enable move reminders in settings' x
read -p ' >> manual: dark theme with purple accent' x
read -p ' >> manual: set wallpaper' x
read -p ' >> manual: set hotkeys:' x
echo '     - [sup + spc] ptyxis '
echo '     - [alt + spc] file '
echo '     - [sup + tab] change input '
