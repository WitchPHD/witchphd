#! /bin/bash

# this script copies config files I use to here to recover from later

echo ' '
read -p ' >> enter: cp config files from system to ./.configs' x
cp ~/.config/kitty/kitty.conf $(dirname "$0")/.configs/kitty.conf
cp ~/.config/starship.toml $(dirname "$0")/.configs/starship.toml 
cp ~/.config/nvim/init.vim $(dirname "$0")/.configs/init.vim
cp /etc/pacman.conf $(dirname "$0")/.configs/pacman.conf
cp ~/.bashrc $(dirname "$0")/.configs/.bashrc
