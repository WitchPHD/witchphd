#! /bin/bash

# this script copies config files I use to here to recover from later

# copy config files to here from their normal home
cp ~/.config/kitty/kitty.conf $(dirname "$0")/kitty.conf
cp ~/.config/starship.toml $(dirname "$0")/starship.toml 
cp ~/.config/nvim/init.vim $(dirname "$0")/init.vim
cp /etc/pacman.conf $(dirname "$0")/pacman.conf
cp ~/.bashrc $(dirname "$0")/.bashrc
