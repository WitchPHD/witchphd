#! /bin/bash

# this script installs all the programs for my desktop
echo ' '
echo ' >> this script is for setting up my arch daily driver'

echo ' '
read -p ' >> enter: install GNOME then uninstall bloat' x
sudo pacman -S gnome
sudo systemctl enable gdm
sudo systemctl start gdm
sudo pacman -R gnome-calendar gnome-weather gnome-tour gnome-music gnome-maps gnome-contacts gnome-user-docs gnome-console gnome-software folks epiphany decibels malcontent yelp sushi showtime simple-scan loupe grilo grilo-plugins gvfs-afc gvfs-dnssd gvfs-goa gvfs-google gvfs-gphoto2 gvfs-mtp gvfs-nfs gvfs-onedrive gvfs-smb gvfs-wsdd


echo ' '
read -p ' >> enter: enable and install multilib' x
# move pacman conf with multilib & download it (for steam and more)
sudo cp $(dirname "$0")/pacman.conf /etc/pacman.conf
sudo pacman -Syu


echo ' '
read -p ' >> enter: install packages' x
# fonts
sudo pacman -S ttf-hack-nerd noto-fonts noto-fonts-cjk
# terminal stuff
sudo pacman -S kitty starship neovim vim-nerdtree man-db fastfetch
# basic DE stuff
sudo pacman -S firefox libreoffice-fresh telegram-desktop power-profiles-daemon transmission-qt
# multimedia
sudo pacman -S gwenview vlc gimp steam obs-studio v4l2loopback-dkms
# security services
sudo pacman -S ufw fail2ban


echo ' '
read -p ' >> enter: enable security services' x
sudo systemctl enable ufw fail2ban
sudo systemctl start ufw fail2ban
sudo ufw enable


echo ' '
read -p ' >> enter: install paru' x
sudo pacman -S --needed base-devel git
git clone https://aur.archlinux.org/paru.git
cd paru
makepkg -si
cd ..
sudo rm -r paru

echo ' '
read -p ' >> enter: install AUR packages' x
# AUR packages (new: driverless dock doesn't need displaylink)
# echo '!! USE EVDI-DKMS-GIT OPTION FOR DISPLAYLINK !!'
paru -S discord-canary #displaylink

echo ' '
read -p ' >> enter: cp config files from ./.configs to system' x
mkdir -p ~/.config/nvim
cp $(dirname "$0")/.configs/arch/kitty.conf ~/.config/kitty/kitty.conf
cp $(dirname "$0")/.configs/arch/starship.toml ~/.config/starship.toml 
cp $(dirname "$0")/.configs/arch/init.vim ~/.config/nvim/init.vim
cp $(dirname "$0")/.configs/arch/.bashrc ~/.bashrc

echo ' '
read -p ' >> enter: run updates' x
paru -c
paru

echo ' ' 
read -p ' >> manual: enable nightlight in settings' x
read -p ' >> manual: enable move reminders in settings' x
read -p ' >> manual: dark theme with purple accent' x
read -p ' >> manual: set wallpaper' x
read -p ' >> manual: set hotkeys:' x
echo '     - [sup + spc] kitty '
echo '     - [alt + spc] file '
