#! /bin/bash

# this script installs all the programs for my desktop

# install & enable gnome
sudo pacman -S gnome
sudo systemctl enable gdm
sudo systemctl start gdm

# uninstall gnome extras
sudo pacman -R gnome-calendar gnome-weather gnome-tour gnome-music gnome-maps gnome-contacts gnome-user-docs gnome-console gnome-software folks epiphany decibels malcontent yelp sushi showtime simple-scan loupe grilo grilo-plugins gvfs-afc gvfs-dnssd gvfs-goa gvfs-google gvfs-gphoto2 gvfs-mtp gvfs-nfs gvfs-onedrive gvfs-smb gvfs-wsdd

# move pacman conf with multilib & download it (for steam and more)
sudo cp $(dirname "$0")/pacman.conf /etc/pacman.conf
sudo pacman -Syu

# fonts
sudo pacman -S ttf-hack-nerd noto-fonts noto-fonts-cjk

# terminal stuff
sudo pacman -S kitty starship neovim vim-nerdtree man-db fastfetch

# basic DE stuff
sudo pacman -S firefox libreoffice-fresh telegram-desktop power-profiles-daemon transmission-qt

# multimedia
sudo pacman -S gwenview vlc gimp steam obs-studio v4l2loopback-dkms

# security services
sudo pacman -S ufw fail2ban

# enable security services
sudo systemctl enable ufw fail2ban
sudo systemctl start ufw fail2ban
sudo ufw enable

# install paru for AUR support
sudo pacman -S --needed base-devel git
git clone https://aur.archlinux.org/paru.git
cd paru
makepkg -si
cd ..
sudo rm -r paru

# AUR packages
echo '!! USE EVDI-DKMS-GIT OPTION FOR DISPLAYLINK !!'
paru -S discord-canary displaylink

# wrap it up
paru -c
paru

