#! /bin/bash

# this script distributes config files from here to the system

# make nvim folder if not there
mkdir -p ~/.config/nvim

# copy config files from here to their normal home
cp $(dirname "$0")/kitty.conf ~/.config/kitty/kitty.conf
cp $(dirname "$0")/starship.toml ~/.config/starship.toml 
cp $(dirname "$0")/init.vim ~/.config/nvim/init.vim
cp $(dirname "$0")/.bashrc ~/.bashrc
